
package Cafeteria;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
import java.util.Scanner;
 

class Pedido {
    private String cliente;
    private String producto;
 
    public Pedido(String cliente, String producto) {
        this.cliente = cliente;
        this.producto = producto;
    }
 
    public String Cliente() {
        return cliente;
    }
 
    public String Producto() {
        return producto;
    }
 
    @Override
    public String toString() {
        return "Cliente: " + cliente + " | Producto: " + producto;
    }
}
 

class Cafeteria {
    private Queue<Pedido> colaPedidos;
    private Stack<Pedido> pilaAtendidos;
 
    public Cafeteria() {
        colaPedidos = new LinkedList<>();
        pilaAtendidos = new Stack<>();
    }
 
    public void agregarPedido(String cliente, String producto) {
        colaPedidos.add(new Pedido(cliente, producto));
        System.out.println("Cliente agregado a la cola.");
    }
 
    public void atenderPedido() {
        if (!colaPedidos.isEmpty()) {
            Pedido atendido = colaPedidos.poll();
            pilaAtendidos.push(atendido);
            System.out.println("Atendiendo " + atendido);
        } else {
            System.out.println("No hay clientes en espera.");
        }
    }
 
    public void mostrarCola() {
        if (colaPedidos.isEmpty()) {
            System.out.println("No hay clientes en espera.");
        } else {
            System.out.println("Clientes en espera:");
            for (Pedido p : colaPedidos) {
                System.out.println(" - " + p);
            }
        }
    }
 
    public void mostrarPedidosAtendidos() {
        if (pilaAtendidos.isEmpty()) {
            System.out.println("No hay pedidos atendidos.");
        } else {
            System.out.println("Ultimos pedidos atendidos (del mas reciente al mas antiguo):");
            for (Pedido p : pilaAtendidos) {
                System.out.println(" - " + p);
            }
        }
    }
}
 

public class SistemaCafeteria {
    public static void main(String[] args) {
        Cafeteria cafeteria = new Cafeteria();
Scanner sc = new Scanner(System.in);
        int opcion;
 
        do {
            System.out.println("\n===== SISTEMA CAFETERIA =====");
            System.out.println("1. Agregar cliente a la cola");
            System.out.println("2. Atender cliente");
            System.out.println("3. Mostrar clientes en espera");
            System.out.println("4. Mostrar ultimos pedidos atendidos");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = sc.nextInt();
            sc.nextLine(); 
            switch (opcion) {
                case 1:
                    System.out.print("Nombre del cliente: ");
                    String nombre = sc.nextLine();
                    System.out.print("Producto solicitado: ");
                    String producto = sc.nextLine();
                    cafeteria.agregarPedido(nombre, producto);
                    break;
 
                case 2:
                    cafeteria.atenderPedido();
                    break;
 
                case 3:
                    cafeteria.mostrarCola();
                    break;
 
                case 4:
                    cafeteria.mostrarPedidosAtendidos();
                    break;
 
                case 5:
                    System.out.println("Saliendo del sistema...");
                    break;
 
                default:
                    System.out.println("Opción invalida, intente de nuevo.");
            }
        } while (opcion != 5);
 
        sc.close();
    }
}
    
   
